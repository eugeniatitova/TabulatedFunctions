package functions;

public class FunctionPointIndexOutOfBoundsException extends IndexOutOfBoundsException {
    FunctionPointIndexOutOfBoundsException(){
        super();
    }
}
