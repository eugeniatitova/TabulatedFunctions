package functions;

public class InappropriateFunctionPointException extends Exception {
    InappropriateFunctionPointException(){
        super();
    }
}
